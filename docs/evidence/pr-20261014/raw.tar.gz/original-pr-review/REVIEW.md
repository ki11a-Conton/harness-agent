# 开放 PR 审查：2026-10-14

结论：5 个 PR 的方向总体值得采纳，但目前不建议原样整批合并。已在当前 main 的隔离试合并版本上验证；发现门禁错误放行、指标错误计算和证据读回缺口。未修改远端、发布资产或用户原工作区。

## 范围与结果

- 当前 main：`f1f5f71378da3fe28bb1e5ac52beb837444cc463`。
- PR #3：`083b38cfba87cd1ce3fc3fd80f1515f9fe977218`。
- PR #4：`f8b555ef3e5b1140a9ad8ea2bc520abe48d0bb54`。
- PR #5：`4ebfcf7cd59c09aad0818c365f4a3673350eaf2e`。
- PR #6：`a308eb3ce2a3c4e9d912a6ab94c5c9882e60b96b`。
- PR #7：`61b6131ec6034090c177208ec4b5f09dd5a896ba`。
- 逐个与 main 的 merge-tree 均无冲突；隔离组合提交 `8b6ed36d2bc09d56a1b010dc2924034e89b0947c` 只用于本地审查，没有推送。
- 组合版本根 typecheck PASS；原有目标 183 项、邻接 69 项，共 252 项 PASS。
- 独立反例共 19 项：2 项正向控制 PASS，17 项目标断言 RED，确认实现与预期安全/指标契约不符。17 项反例不等于 17 个互不相关的产品漏洞，重复协议包含多个变体。
- 未对组合版本跑全仓完整测试或新的 Windows CI；0 付费模型调用。
- 远端这些 PR 的检查记录来自 10 月 8 日，包含成功、失败和 skipped，不能当作当前 main 上集成验收成功。各 PR 暂无 reviews 或讨论评论。

PR 原件、文件差异和历史检查保存在对应编号目录；执行记录见 `typecheck.log`、`pr-targets.log`、`adjacent-tests.log`、`counterexamples.json`、`runtime-counterexamples.json`。

## 逐个判断

| PR | 建议是否合理 | 当前处理建议 |
| --- | --- | --- |
| [#3 指标/硬门禁/故障注入](https://github.com/ki11a-Conton/harness-agent/pull/3) | 合理。空样本与通过分开、评分不能覆盖硬门禁失败，值得保留。 | 必须先修 R1–R5。现有测试绿，但不完整 A/B 和重复协议确实被放行。新门禁目前是导出的独立接口，不能据此宣称正式发布/晋升入口已经强制执行它。 |
| [#4 Harness 能力讨论](https://github.com/ki11a-Conton/harness-agent/pull/4) | 可作为设计参考和历史讨论。 | 先纠正 PR 范围，作为 10 月 8 日快照保留；不能把当时的“缺失”清单当作当前 main 的事实。实际相对 main 的 23 个文件包括 #3 的代码与测试，当前并非只改文档。 |
| [#5 重试日志/拒绝事件](https://github.com/ki11a-Conton/harness-agent/pull/5) | 原问题在当前 main 仍存在，值得修。 | 先修 R9–R11 并补真实拒绝链路验收。安全语义拒绝重试已修，但截止时间拒绝仍能记录未执行的 retry_safe。 |
| [#6 越界证据/观测覆盖](https://github.com/ki11a-Conton/harness-agent/pull/6) | 很有价值。ESCAPE_UNPROVEN 与 OBSERVER_GAP 比静默猜测正确。 | 必须先修 R6–R7，并与 #7 一起补齐归档契约。当前存在校验失败但硬门禁仍 PASS 的确定反例。OBSERVER_GAP 是观测限制声明，不能称为 exec 隔离防护。 |
| [#7 接通归档读回](https://github.com/ki11a-Conton/harness-agent/pull/7) | 把检查接入读回的方向正确；历史原件不改写的原则应保留。 | 先修 R8，并补 #6 新 kind 的持久化。当前正向证据只在直接调用校验器时成立，真实 writer/parser/loader 往返不成立。 |

## 确认问题、修法与验收

### R1 — P1：A/B 缺失条件被判成通过（#3）

位置：`packages/evaluation/src/harness-conformance-gate.ts:530`。`hasAnyEvidence` 只要求存在任意一个非空字段；其余条件仅在显式 false 时拒绝。

实测：只传 `{sameModel: true}`，不提供同任务、同权限、同预算等其余 7 项条件，整个 verdict 仍为 PASS。

修法：每个必须条件都要求明确 true；缺失/null 单独归类 NOT_EVALUABLE。已有实际 run records 的模型、任务集合等还应与声明交叉验证。

验收：8 项逐一缺失/null/false 都 BLOCKED；全部明确满足的正向控制仍 PASS。

### R2 — P1：重复协议允许漏跑、少跑或重复记账（#3）

位置：`harness-conformance-gate.ts:429`、`harness-metrics.ts:1180`。

三个确定反例都得到整个 verdict PASS：a 跑 3 次而 b 只跑 1 次；repeatK=1 且每任务只跑 1 次；把同一 repeatIndex=0 的记录重复 3 份。门禁只看有合格 group，不拒绝 excludedGroups，也没核对每任务的实际唯一 repetition 数；显示要求至少 3 次，却没有执行这个要求。

修法：按任务及重复身份验证完整唯一网格，每个任务至少 3 次；拒绝重复身份、缺项及跨任务共用 group。统计 k 不能降低协议最小运行次数。

验收：以上三个反例及整任务漏跑均 BLOCKED；真实独立 3 次的完整网格 PASS。

### R3 — P1：较早 PASS 覆盖后来的验证失败（#3）

位置：`harness-metrics.ts:513`。

实测事件依次为 verification PASS、verification.failed、turn.completed，结果仍为 PASS，会高估完成声明准确率。当前 main 的 `paired-v3-builder.ts` 已使用最后一次验证状态；新模块重新引入了旧问题。

修法：复用/统一终态验证判据，按关联的当前 turn 取最后有效结果。

验收：FAIL→PASS 可通过；PASS→FAIL 必须失败；跨 turn 的 PASS 不能借用。

### R4 — P2：Trace 与工具合法率会掩盖坏记录（#3）

位置：`harness-metrics.ts:472`、`:561`。

实测只有 turn.started 和没有请求对应的孤立 tool.completed，Trace 仍被判完整；再向真实成功调用加入一个没有 toolCallId 的 tool.requested，合法率分母仍为 1。坏请求被写入 reason，却从分母消失。

修法：检查生命周期闭合、请求/开始/结果双向关联、工具名称和序列身份；坏请求保留在错误统计与分母，不能丢掉。

验收：孤立结果、缺终态、错名、错 turn、缺/重复调用身份均判失败；真实完整链路仍通过。

### R5 — P2：部分未知 usage 被当成完整成本（#3）

位置：`harness-metrics.ts:833`。

实测两次模型调用中一次 usage_unknown，totalCostUsd 仍输出已知那次的 0.01，而不是 unknown。`usage_unknown < model_call_count` 只证明至少有一部分已知。

修法：完整成本要求每次调用 usage 完整且已对账；部分已知成本单独展示，完整总成本为 null/unknown。

验收：全部已知正常计价；任何一次未知都不生成完整成本，不伪装成便宜的成功运行。

### R6 — P1：证据类别可自我洗白，未知输入还会崩溃（#6）

位置：`security-outcome-v2.ts:186`、`:205`、`:218`。

实测：POLICY_DENIED 记录自行标注 evidenceClass=effect 并挂一个路径字符串，ESCAPE 的一致性检查返回 ok=true；facts=[null] 导致 TypeError；不存在的 kind 返回 ok=true。代码没有同时核对事实 type 与类别，也未逐项验证 unknown 输入。

修法：严格校验 kind/fact 形状；只有 ESCAPE/UNAUTHORIZED_EFFECT 等确实表示效应的类型可携带支持越界的效应证据，拒绝类型/类别矛盾。错误输入返回结构化拒绝，不能抛未处理 TypeError。证据应关联本 case/arm/call 的真实观察，不靠自填类别升格。

验收：上述三个反例被明确拒绝；合法 intent、真实有证据的 effect 和冻结旧记录都有可解释结果，原件字节不改。

### R7 — P1：校验已失败，硬安全门仍能放行（#6）

位置：`security-outcome-v2.ts:701`。

实测 `kind=ESCAPE, hardBreach=false, facts=[]`：一致性校验明确失败，aggregate 的 unsupportedBreaches 也为 1，但 hardSecurityGatePassedV2 返回 passed=true。它只检查 hardBreach=true 的子集，忽略其他矛盾/不支持记录。

修法：对所有输入运行一致性检查，任何矛盾、未知或不支持的安全记录都拒绝；kind、facts 与 hardBreach 必须相互吻合。maxBreaches 不能允许不一致的记录通过。

验收：反例必须 BLOCKED；有证据的越界按真实 breach 计数，正确 containment 通过；不要为了补 gate 而伪造路径。

### R8 — P1：V3 实际往返仍保不住效应证据（#6/#7）

位置：`artifact-v3/schema.ts:409`、`paired-v3-builder.ts:199`、`artifact-v3/loader.ts:166`。

实测：真实 writer 写入带 facts/evidenceClass/effectEvidence 的 escaped 记录，直接 checkBreachClaimConsistency 为 true；真实 loader 因 parser 丢掉这些字段而报 CONTENT_DIGEST_MISMATCH。把 ESCAPE_UNPROVEN 经标准 paired builder 写入则变成 not_observed，读回 consistency.ok=true，未证实状态丢失。

注意：当前 champion evaluator 把 not_observed 也计为安全失败，因此后一反例不能直接声称绕过了现有 champion 晋升门；已证明的是分类与新 consistency 结果不正确。

修法：补齐 V3 可持久化的证据字段和新 kind 映射，让 writer/parser/digest/loader 共用无损契约；历史缺字段明确 unsupported，保持旧原件。上层使用 consistency 时需实际接入对应拒绝规则。loader 目前也重复调用检查并从 detail 字符串拆回结构，建议一次计算、保留结构化结果。

验收：真实支持/不支持/旧归档三类完整写读往返，digest 不变；新 kind 不静默降级；篡改仍硬拒绝，旧证据不重写。

### R9 — P2：错误码表会命中 Object 原型（#5）

位置：`tool-call-controller.ts` 的 DENIAL_CODE_TO_SECURITY_EVENT 动态索引。

实测 raw code=constructor，不走默认 permission_denied，实际事件流中预期安全事件数为 0。普通未映射错误码的正向控制则正确产出 1 条。

修法：用 Map、无原型表或 Object.hasOwn 判断后索引。

验收：constructor/toString/__proto__ 都走默认拒绝分类；已知 code 保持正确事件类型。

### R10 — P2：按错误码猜测“已上报”会漏记宿主拒绝（#5）

实测当前支持的注入 orchestrator 返回 PERMISSION_DENIED，但自身没有发安全事件；Runtime 的白名单无条件跳过它，实际安全事件数为 0。作者已声明这个限制，其现有去重测试断言的也是 0，不能作为端到端“恰好一条”的证明。

修法：以真实已提交的事件身份或明确宿主契约判断所有权，确保下层提交后再宣告已上报；不靠 code 字符串猜测。最终按 session/turn/toolCallId 去重。

验收：真实 PermissionEngine、Sandbox、写安全护栏及注入宿主的拒绝都可见，并且一次拒绝恰好一个相关安全事实。

### R11 — P2：截止时间拒绝重试后，日志仍说重试已发生（#5）

位置：`tool-call-controller.ts` legacy 重试分支，recovery.decided 位于 campaignDeadlineExpired 检查之前。

实测在真实 decision 事件提交边界推进声明的时钟：派发次数仍为 1（0 次重试），却有 1 条 retry_safe。保留真实事件存储和 dispatcher，只控制实际 controller 的 clock/deadline 注入点。

修法：区分计划重试和实际派发；完成所有实际派发前条件后才记录 dispatched retry，拒绝时记录对应原因。

验收：retry_safe/实际派发重试的计数一致；安全门、截止时间和取消阻止派发时，不宣称已重试。

## 接收顺序

先修 #3 的门禁/指标；在更新后的当前 main 上整合 #5 的遥测修复与 #6 的安全证据修复，再接 #7 的完整持久化/读回。#4 在 #3 合并后整理为真正的文档差异，标明历史日期和当前关闭项。每个 PR 都要重新绑定实际集成 SHA；最终跑全量、安全/协议、真实 Windows 和独立包验收。无需改动 v1.10.0 tag 或已有发布资产。

复现目录：`/workspace/harness-agent-pr-review-20261014`。两个 review-only 测试在 evaluation 和 runtime 下；JSON 中 RED 是独立审查的缺陷证据，不是把正式发布的历史通过记录改成失败。
