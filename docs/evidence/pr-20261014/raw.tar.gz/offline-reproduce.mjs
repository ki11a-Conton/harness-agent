import { chromium } from '/workspace/scratch/deepseek-acceptance/node_modules/playwright/index.mjs';
import { mkdir, writeFile } from 'node:fs/promises';
const out='/workspace/scratch/pr-integration-web/offline-red';await mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1440,height:1000}});
const observations=[];const log=[];
page.on('console',msg=>log.push({kind:'console',type:msg.type(),text:msg.text()}));
page.on('pageerror',err=>log.push({kind:'error',text:err.message}));
page.on('websocket',ws=>{log.push({kind:'socket',url:ws.url()});ws.on('framereceived',e=>{try{const f=JSON.parse(String(e.payload));if(f.value?.type==='ready'||f.value?.__deepseek_transport_error__)log.push({kind:'received',frame:f});}catch{}});ws.on('close',()=>log.push({kind:'closed',url:ws.url()}));});
await page.addInitScript(() => Object.defineProperty(Navigator.prototype, 'onLine', { get: () => false, configurable: true }));
await page.goto('http://127.0.0.1:8793/',{waitUntil:'domcontentloaded'});
for(const seconds of [2,8]){await page.waitForTimeout((seconds-(observations.at(-1)?.seconds??0))*1000);const text=await page.locator('body').innerText();observations.push({seconds,text});await page.screenshot({path:`${out}/${seconds}.png`,fullPage:true});await writeFile(`${out}/result.json`,JSON.stringify({observations,log},null,2));console.log(JSON.stringify({seconds,notice:text.match(/.{0,45}(?:reconnect|connect|连接).{0,75}/gi),log:log.slice(-4)}));}
await browser.close();
