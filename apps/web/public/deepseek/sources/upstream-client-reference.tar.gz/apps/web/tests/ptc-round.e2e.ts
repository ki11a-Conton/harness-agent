// PTC mode browser round trip with nested sub-calls and details selection.
// Record: DSH_SNAPSHOT=record writes session.v3.jsonl, then a keyless
// DSH_SNAPSHOT=refresh regenerates ui.expected.md.
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import type { Browser, Page } from 'playwright'
import { chromium } from 'playwright'
import { afterAll, beforeAll, describe, expect, it, onTestFailed } from 'vitest'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import {
  acknowledgeReloadConnectionLoss, captureExpandedTurnProcessAria, captureStableAria, compareOrRefreshGolden, fixtureUserPrompts,
  launchWebScaffold, recordFixture, watchConsole, webSnapshotMode, type WebScaffold,
} from './scaffold.ts'
import { connectFreshWorkspace, expandOwningTurnProcess, newEnglishPage, saveFailureShot } from './support.ts'

const FIXTURE = fileURLToPath(new URL('../../../snapshots/web/ptc-round/session.v3.jsonl', import.meta.url))
const UI_EXPECTED = fileURLToPath(new URL('../../../snapshots/web/ptc-round/ui.expected.md', import.meta.url))
const TRAJECTORY_EXPECTED = fileURLToPath(new URL('../../../snapshots/web/ptc-round/trajectory.expected.md', import.meta.url))
const CODE_EXPECTED = fileURLToPath(new URL('../../../snapshots/web/ptc-round/code.expected.md', import.meta.url))
const PREPARING_EXPECTED = fileURLToPath(new URL('../../../snapshots/web/ptc-round/preparing.expected.md', import.meta.url))
const MODE = webSnapshotMode()

// Elicits the successful and failed sub-rows this scenario asserts.
const PROMPT = 'Using ONE run_code program: run bash `echo CODE_ROUND_OK`, then read the file missing.txt '
  + 'catching its error in the program. Return an object with both outcomes. Then reply DONE and stop.'

describe('web e2e: PTC mode round renders nested sub-calls', () => {
  let scaffold: WebScaffold
  let browser: Browser
  let page: Page
  let tripwire: ReturnType<typeof watchConsole>
  const sessionEvents: SessionEvent[] = []
  let releasePreparation: (() => void) | undefined

  beforeAll(async () => {
    scaffold = await launchWebScaffold({
      agentPresets: { default: 'ptc' },
      compareReplaySession: true,
      ...(MODE === 'record' ? {} : { replayFixture: FIXTURE, paceMs: 15 }),
    })
    scaffold.ctx.on('session/event', (_session, event: SessionEvent) => { sessionEvents.push(event) })
    browser = await chromium.launch()
    page = await newEnglishPage(browser)
    tripwire = watchConsole(page)
    await page.goto(scaffold.authenticatedUrl, { waitUntil: 'load' })
    await page.waitForSelector('[class*="frame"]', { timeout: 30_000 })
    await connectFreshWorkspace(page, scaffold.workspaceCwd)
  }, 120_000)

  afterAll(async () => {
    releasePreparation?.()
    await browser?.close()
    await scaffold?.close()
  })

  it('drives the recorded prompt to a settled turn (all modes)', async () => {
    onTestFailed(() => saveFailureShot(page, 'web-e2e-ptc-drive'))
    if (MODE !== 'record') {
      expect(fixtureUserPrompts(await readFile(FIXTURE, 'utf8'))).toEqual([PROMPT])
    }
    const input = page.locator('[data-composer-input]').first()
    await input.waitFor({ timeout: 10_000 })
    const settled = scaffold.whenTurnSettled()
    const gate = Promise.withResolvers<undefined>()
    const dispose = scaffold.ctx.on('llm/stream', async function* (_options, next) {
      let held = false
      for await (const chunk of next()) {
        yield chunk
        if (!held && chunk.type === 'tool-call-delta' && chunk.name) {
          held = true
          await gate.promise
        }
      }
    }, { prepend: true })
    releasePreparation = () => { gate.resolve(undefined); dispose() }
    const observePreparation = async () => {
      try {
        await input.fill(PROMPT)
        await input.press('Enter')
        const row = page.locator('[data-chat-call-id] [data-state="preparing"]').first()
        await row.waitFor({ state: 'attached', timeout: 30_000 })
        await expandOwningTurnProcess(page, row)
        await row.waitFor({ state: 'visible' })
        await row.getByText('Code', { exact: true }).waitFor()
        expect(await row.getAttribute('data-tool')).toBe('run_code')
        expect(sessionEvents.some(event => event.type === 'tool/call')).toBe(false)
        expect(await row.getByRole('button').count()).toBe(0)
        expect(await row.locator('pre').count()).toBe(0)
        const group = row.locator('xpath=ancestor::*[@data-chat-group-key][1]')
        await compareOrRefreshGolden(PREPARING_EXPECTED, await group.ariaSnapshot(), MODE)
      } finally {
        releasePreparation?.()
      }
    }
    const [sessionId] = await Promise.all([settled, observePreparation()])
    await expect.poll(() => page.locator('[data-state="preparing"]').count(), { timeout: 15_000 }).toBe(0)
    if (MODE === 'record') {
      await recordFixture(scaffold, sessionId, FIXTURE)
    }
  }, 200_000)

  it.skipIf(MODE === 'record')('the durable log carries run_code with full-content sub-dispatches', () => {
    const calls = sessionEvents.filter(event => event.type === 'tool/call')
    expect(calls.length).toBeGreaterThanOrEqual(1)
    expect(new Set(calls.map(call => (call.data as { name: string }).name))).toEqual(new Set(['run_code']))
    const starts = sessionEvents.filter(event => event.type === 'tool/ptc-dispatch-start')
    const dispatches = sessionEvents.filter(event => event.type === 'tool/ptc-dispatch')
    expect(dispatches.length).toBeGreaterThanOrEqual(2)
    for (const dispatch of dispatches) {
      const data = dispatch.data
      expect(calls.some(call => call.data.callId === data.rootCallId)).toBe(true)
      expect(data.parentCallId).toBe(data.rootCallId)
      expect(starts.filter(start => start.data.subCallId === data.subCallId)).toMatchObject([{
        data: {
          rootCallId: data.rootCallId,
          parentCallId: data.parentCallId,
          subCallId: data.subCallId,
          name: data.name,
          arguments: data.arguments,
        },
      }])
      expect(Array.isArray(data.content)).toBe(true)
      expect(typeof data.isError).toBe('boolean')
    }
    const bash = dispatches.find(dispatch => (dispatch.data as { name: string }).name === 'bash')
    expect(bash).toBeDefined()
    const bashContent = (bash!.data as { content: { type: string; text?: string }[] }).content
    expect(bashContent.filter(block => block.type === 'text').map(block => block.text).join('')).toContain('CODE_ROUND_OK')
  })

  it.skipIf(MODE === 'record')('renders the code parent row with always-visible nested sub-rows', async () => {
    onTestFailed(() => saveFailureShot(page, 'web-e2e-ptc-rows'))
    await expect.poll(() => page.getByText('DONE', { exact: true }).count(), { timeout: 15_000 }).toBeGreaterThanOrEqual(1)
    // The parent run_code row wears the code variant with the model-authored
    // description as its summary (the presentCall contract).
    const codeRow = page.locator('[data-variant="code"]').first()
    await expandOwningTurnProcess(page, codeRow)
    await codeRow.waitFor({ timeout: 10_000 })
    const nest = page.locator('[data-subcalls]').first()
    await nest.waitFor({ timeout: 10_000 })
    expect(await nest.locator('[data-sample="bash"]').count()).toBeGreaterThanOrEqual(1)
    expect(await nest.locator('[data-state="error"]').count()).toBeGreaterThanOrEqual(1)
  }, 60_000)

  it.skipIf(MODE === 'record')('expands the nested bash terminal inline before and after reload', async () => {
    onTestFailed(() => saveFailureShot(page, 'web-e2e-ptc-rightbar'))
    let liveTerminalAria: string | undefined
    for (const reloaded of [false, true]) {
      if (reloaded) {
        const warningStart = tripwire.warnings.length
        await page.reload({ waitUntil: 'load' })
        acknowledgeReloadConnectionLoss(tripwire, warningStart)
        await page.getByText('DONE', { exact: true }).waitFor({ timeout: 15_000 })
        await expect.poll(() => page.locator('[data-state="preparing"]').count(), { timeout: 15_000 }).toBe(0)
      }
      const nest = page.locator('[data-subcalls]').first()
      const frame = page.locator('[style*="grid-template-columns"]').first()
      expect(await frame.getAttribute('data-rightbar-collapsed')).toBe('true')
      await expandOwningTurnProcess(page, nest)
      const row = nest.locator('[data-sample="bash"]').first()
      await expect.poll(() => row.getAttribute('data-state')).toBe('ok')
      await expect.poll(() => row.getAttribute('aria-expanded')).toBe('false')
      await row.click()
      await expect.poll(() => row.getAttribute('aria-expanded')).toBe('true')
      const terminal = row.locator('xpath=..').locator('[data-terminal]')
      await terminal.waitFor()
      await terminal.getByText('echo CODE_ROUND_OK', { exact: true }).waitFor()
      await terminal.getByText('CODE_ROUND_OK', { exact: true }).waitFor()
      await expect.poll(() => terminal.locator('[data-state]').getAttribute('data-state')).toBe('done')
      await expect.poll(() => frame.getAttribute('data-rightbar-collapsed'), { timeout: 5_000 }).toBe('true')
      const aria = await terminal.ariaSnapshot()
      if (reloaded) expect(aria).toBe(liveTerminalAria)
      else liveTerminalAria = aria
    }
  })

  it.skipIf(MODE === 'record')('matches the expanded conversation aria golden with stable anchors', async () => {
    onTestFailed(() => saveFailureShot(page, 'web-e2e-ptc-aria'))
    const row = page.locator('[data-subcalls] [data-sample="bash"]').first()
    await expandOwningTurnProcess(page, row)
    if (await row.getAttribute('aria-expanded') !== 'true') await row.click()
    const snapshot = await captureExpandedTurnProcessAria(
      page,
      '[class*="centerCol"]',
      scaffold.workspaceCwd,
    )
    await compareOrRefreshGolden(UI_EXPECTED, snapshot, MODE)
  })

  it.skipIf(MODE === 'record')('inspects recorded PTC source, wrapping, and original JSON in the trajectory', async () => {
    onTestFailed(() => saveFailureShot(page, 'web-e2e-ptc-inspector'))
    const call = sessionEvents.find(event => event.type === 'tool/call' && event.data.name === 'run_code')
    if (call?.type !== 'tool/call') throw new Error('recorded PTC call missing')
    const args = JSON.parse(call.data.arguments) as { code: string; description: string }
    await page.getByRole('tab', { name: 'Trajectory', exact: true }).click()
    const row = page.locator('tr[data-kind="tool"]').filter({ hasText: 'run_code' }).first()
    await row.click()
    await page.getByRole('tab', { name: 'Code', exact: true }).waitFor()
    expect(await page.getByRole('tabpanel').textContent()).toContain(args.description)
    expect(await page.getByRole('tabpanel').locator('dl').first().locator('dt').allTextContents())
      .toEqual(['Hierarchy', 'Status'])
    const overview = await Promise.all([1, 2].map(index => captureStableAria(
      page, `[role="tabpanel"] [class*="overviewSections"] > section:nth-child(${index})`, scaffold.workspaceCwd,
    )))
    await compareOrRefreshGolden(TRAJECTORY_EXPECTED, overview.join('\n'), MODE)

    await page.getByRole('button', { name: 'Code', exact: true }).click()
    const source = page.locator('[data-line-numbers] pre')
    await source.waitFor()
    expect(await source.textContent()).toBe(args.code.endsWith('\n') ? args.code.slice(0, -1) : args.code)
    const wrap = page.getByRole('button', { name: 'Wrap lines', exact: true })
    expect(await wrap.getAttribute('aria-pressed')).toBe('false')
    const content = page.locator('[data-wrap]').filter({ has: source })
    expect(await content.evaluate(element => element.scrollWidth > element.clientWidth)).toBe(true)
    await wrap.click()
    expect(await wrap.getAttribute('aria-pressed')).toBe('true')
    await expect.poll(() => content.evaluate(element => element.scrollWidth - element.clientWidth)).toBeLessThanOrEqual(1)
    const code = await captureStableAria(page, '[role="tabpanel"]', scaffold.workspaceCwd)
    await compareOrRefreshGolden(CODE_EXPECTED, code, MODE)

    await page.getByRole('button', { name: 'Original JSON' }).click()
    const json = page.getByRole('tree', { name: 'parameters JSON' })
    await json.waitFor()
    expect(await json.textContent()).toContain(args.description)
    await page.getByRole('button', { name: 'Original JSON' }).click()
    expect(await source.textContent()).toBe(args.code.endsWith('\n') ? args.code.slice(0, -1) : args.code)
    await page.getByRole('tab', { name: 'Summary', exact: true }).click()
    expect(await wrap.getAttribute('aria-pressed')).toBe('true')
  })

  it.skipIf(MODE === 'record')('stayed clean: no page errors, no reconnect churn', () => {
    expect(tripwire.pageErrors).toEqual([])
    expect(tripwire.warnings).toEqual([])
  })
})
